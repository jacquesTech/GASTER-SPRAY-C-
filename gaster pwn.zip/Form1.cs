﻿using LibUsbDotNet;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using LibUsbDotNet.DeviceNotify;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using static gaster_pwn.Form1;
using System.IO;
using System.Runtime.InteropServices;
using System.Diagnostics.Eventing.Reader;

namespace gaster_pwn
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            getFullIdeviceInfo();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            gaster_pwn();
        }








        private bool getIdeviceInfo(string argument = @"")
        {
            CheckForIllegalCrossThreadCalls = false;
            Process ideviceinfo = new Process();
            //ideviceinfo = new Process();
            ideviceinfo.StartInfo.FileName = Environment.CurrentDirectory + "/files/irecovery.exe";
            ideviceinfo.StartInfo.Arguments = "-q";
            ideviceinfo.StartInfo.UseShellExecute = false;
            ideviceinfo.StartInfo.RedirectStandardOutput = true;
            ideviceinfo.StartInfo.CreateNoWindow = true;

            ideviceinfo.Start();

            var lines = 0;

            while (!ideviceinfo.StandardOutput.EndOfStream)
            {
                lines++;

                string line = ideviceinfo.StandardOutput.ReadLine();

                var text2 = line.Replace("\r", "");

                if (text2.StartsWith("ECID: "))
                {
                    if (label3.Text == "UDID:")
                    {
                        label3.Text = "ECID:";
                    }
                    var text3 = text2.Replace("ECID: ", "");
                    iOSDevice.ECID = text3.Trim();
                    labelECID.Text = text3.Trim().ToUpper();
                }
                else if (text2.StartsWith("PRODUCT: "))
                {
                    var text3 = text2.Replace("PRODUCT: ", "");
                    iOSDevice.ProductType = text3;
                    labelProduct.Text = iOSDevice.ProductType;

                }
                else if (text2.StartsWith("CPID: "))
                {
                    var text3 = text2.Replace("CPID: ", "");
                    iOSDevice.CPID = text3;
                    labelCPID.Text = iOSDevice.CPID;
                }

                else if (text2.StartsWith("NAME: "))
                {
                    var text3 = text2.Replace("NAME: ", "");
                    iOSDevice.Model = text3;
                }
                else if (text2.StartsWith("MODEL: "))
                {
                    var text3 = text2.Replace("MODEL: ", "");
                    iOSDevice.MODEL = text3;
                    labelModel.Text = iOSDevice.MODEL;
                }
                else if (text2.StartsWith("MODE: "))
                {
                    var text3 = text2.Replace("MODE: ", "");
                    iOSDevice.mode = text3;
                }
                else if (text2.StartsWith("PWND: "))
                {
                    var text3 = text2.Replace("PWND: ", "");
                    iOSDevice.ipwndfu = text3;

                }

                var split = line.Split(new char[] { ':' });
            }
            checkxploit();
            labelModel.Text = iOSDevice.Model + " Connected in " + iOSDevice.mode + " Mode.";
            labelPWND.Text = iOSDevice.xploit;
            Interlocked.Exchange(ref deviceInfoLock, 0);

            if (lines <= 2)
            {
                return false;
            }

            return true;
        }

        public void checkxploit()
        {
            switch (iOSDevice.ipwndfu)
            {
                case "CHECKM8":
                    iOSDevice.xploit = "YES";
                    labelPWND.ForeColor = Color.SpringGreen;
                    break;
                case "ECLIPSA":
                    iOSDevice.xploit = "YES";
                    labelPWND.ForeColor = Color.SpringGreen;
                    break;
                case "GASTER":
                    iOSDevice.xploit = "YES";
                    labelPWND.ForeColor = Color.SpringGreen;
                    break;
                case "GASTDER":
                    iOSDevice.xploit = "YES";
                    labelPWND.ForeColor = Color.SpringGreen;
                    break;
                case "IPWNDER":
                    iOSDevice.xploit = "YES!";
                    labelPWND.ForeColor = Color.Red;
                    break;
                default:
                    iOSDevice.xploit = "NO";
                    labelPWND.ForeColor = Color.Red;
                    break;
            }
        }

        private void Button(bool x)
        {
            buttonPWND.Enabled = x;
         

        }

        private void DeviceDisconnect()
        {
            Button(false);
            labelECID.Text = "-";
            labelPWND.Text = "False";
            labelPWND.ForeColor = Color.Red;
            iOSDevice.OS = "-";
            iOSDevice.ipwndfu = "-";
            iOSDevice.mode = "-";
            iOSDevice.Model = "-";
            iOSDevice.ECID = "-";
            labelModel.Text = "Connect your device in DFU MODE";

        }
        //-----------< Connect Device Action >---------------------------

        private void DeviceConnected()
        {
            Form1 frm1 = (Form1)Application.OpenForms["Form1"];
          
            Button(true);
        }


        private static int deviceInfoLock = 0;

        public Process proceso = new Process();
        private void getFullIdeviceInfo()
        {
            CheckForIllegalCrossThreadCalls = false;

            if (0 == Interlocked.Exchange(ref deviceInfoLock, 1))
            {
                var res = getIdeviceInfo();

                if (res == false)
                {
                    DeviceDisconnect();
                }
                else
                {

                    DeviceConnected();
                }
            }
            else
            {
                Console.WriteLine("   {0} was denied the lock", Thread.CurrentThread.Name);
            }
        }


        public void p(int number, string message = "")
        {
            Form1 frm1 = (Form1)Application.OpenForms["Form1"];
            frm1.Invoke((MethodInvoker)delegate
            {
                frm1.reportProgress(number, number.ToString());
            });
            if (iOSDevice.debugMode)
            {
                Console.WriteLine(number + message);
            }
            frm1.SetText(message);
        }



        public void SetText(string message)
        {
            labelmessage.Text = message;
        }
        public void reportProgress(int perCent, string label)
        {
            progressBar1.Value = perCent;
           
        }

        public static class DetectOsSystem
        {
            [DllImport("kernel32.dll")]
            static extern IntPtr GetCurrentProcess();

            [DllImport("kernel32.dll")]
            static extern IntPtr GetModuleHandle(string moduleName);

            [DllImport("kernel32")]
            static extern IntPtr GetProcAddress(IntPtr hModule, string procName);

            [DllImport("kernel32.dll")]
            static extern bool IsWow64Process(IntPtr hProcess, out bool wow64Process);

            public static bool Is64BitOperatingSystem()
            {
                if (IntPtr.Size == 8)
                    return true;
                IntPtr moduleHandle = GetModuleHandle("kernel32");
                if (moduleHandle != IntPtr.Zero)
                {
                    IntPtr processAddress = GetProcAddress(moduleHandle, "IsWow64Process");
                    if (processAddress != IntPtr.Zero)
                    {
                        bool result;
                        if (IsWow64Process(GetCurrentProcess(), out result) && result)
                            return true;
                    }
                }
                return false;
            }
        }
        public void Install_libusbK()
        {
            if (DetectOsSystem.Is64BitOperatingSystem())
            {
                InstallDriver("drivers\\install_x64.exe", "Apple_Mobile_Device_(DFU_Mode).inf");
            }
            else
            {
                InstallDriver("drivers\\install_x86.exe", "Apple_Mobile_Device_(DFU_Mode).inf");
            }
        }

        private string Cmd(string Processname, string cmd)
        {
            try
            {

                Process process = new Process()
                {
                    StartInfo = new ProcessStartInfo()
                    {
                        UseShellExecute = false,
                        CreateNoWindow = true,
                        FileName = Processname,
                        Verb = "runas",
                        Arguments = cmd,
                        WorkingDirectory = Path.GetDirectoryName(Processname),
                        RedirectStandardOutput = true,
                        RedirectStandardError = true
                    }
                };
                process.Start();
                return process.StandardOutput.ReadToEnd() + process.StandardError.ReadToEnd();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        private void InstallDriver(string Processname, string inf, bool uninstall = false)
        {
            if (uninstall)
            {
                // Log.RichLog.RichLogs("Uninstalling driver ..", Color.Black, false, false);
            }
            else
            {
                // Log.RichLog.RichLogs("Installing driver ..", Color.Black, false, false);
            }

            if (!File.Exists(Processname))
            {
                throw new Exception("Process data not found ");
            }

            try
            {
                Driver_cmd(Processname, inf, uninstall);
                //Log.RichLog.RichLogs(" OK ", Color.Green,true,true);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }


        private string Driver_cmd(string Processname, string inf, bool uninstall = false)
        {
            string cmd = "";
            if (uninstall)
            {
                cmd = string.Format("uninstall --inf=\"{0}\"", inf);
            }
            else
            {
                cmd = string.Format("install --inf=\"{0}\"", inf);
            }
            Process process = new Process()
            {
                StartInfo = new ProcessStartInfo()
                {
                    UseShellExecute = false,
                    CreateNoWindow = true,
                    FileName = Processname,
                    Verb = "runas",
                    Arguments = cmd,
                    WorkingDirectory = Path.GetDirectoryName(Processname),
                    RedirectStandardOutput = true,
                    RedirectStandardError = true
                }
            };
            process.Start();
            return process.StandardOutput.ReadToEnd() + process.StandardError.ReadToEnd();
        }

        public void Uninstall_libusbk()
        {
            if (DetectOsSystem.Is64BitOperatingSystem())
            {
                InstallDriver("drivers\\install_x64.exe", "Apple_Mobile_Device_(DFU_Mode).inf", true);
            }
            else
            {
                InstallDriver("drivers\\install_x86.exe", "Apple_Mobile_Device_(DFU_Mode).inf", true);
            }
        }

        public void Install_usb()
        {
            this.InstallDriver("files/x64\\install-filter.exe", "usbaapl64.inf", false);
        }

        public void gaster_pwn()
        {
            p(10, "checking device...");
            Install_libusbK();
            p(20, "installing Libusbk drivers...");
            ProcessStartInfo processStartInfo = new ProcessStartInfo();
            p(30, "Checking Computer operating system...");
            processStartInfo.WindowStyle = ProcessWindowStyle.Hidden;
            p(40, "Starting GASTER pwn process...");
            processStartInfo.FileName = ".\\files\\iexp";
            p(50, "Exploiting using CPID...");
            BatchProc = Process.Start(processStartInfo);
            Thread.Sleep(10000);
            p(60, "Ex");
            fixpwn();
            p(70, "");
            Install_usb();
            p(80, "");
            getFullIdeviceInfo();
            try
            {
                bool flag = labelPWND.Text == "N/A";
                if (flag)
                {
                    labelmessage.Text = ("Device refuse to receive gaster pwn patches");
                    MessageBox.Show("PwnDFU Failed..\nTurn on your device..\nThen enter DFU MODE and click PwnDFU again!!", "GASTER", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
                else
                {
                    p(100, "");
                    MessageBox.Show("GASTER", "Device is successfully pwnd by GASTER", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                }
            }
            catch
            {
            }
        }

        public Process BatchProc = null;
        public void fixpwn()
        {
            BatchProc = Process.Start(new ProcessStartInfo
            {
                WindowStyle = ProcessWindowStyle.Hidden,
                FileName = "files\\iusb"
            });
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            
                }

        private void button1_Click_1(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
