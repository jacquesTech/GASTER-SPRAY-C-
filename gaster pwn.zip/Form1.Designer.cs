﻿namespace gaster_pwn
{
    partial class Form1
    {
        /// <summary>
        /// Variable nécessaire au concepteur.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Nettoyage des ressources utilisées.
        /// </summary>
        /// <param name="disposing">true si les ressources managées doivent être supprimées ; sinon, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Code généré par le Concepteur Windows Form

        /// <summary>
        /// Méthode requise pour la prise en charge du concepteur - ne modifiez pas
        /// le contenu de cette méthode avec l'éditeur de code.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.progressBar1 = new System.Windows.Forms.ProgressBar();
            this.buttonPWND = new System.Windows.Forms.Button();
            this.labelmessage = new System.Windows.Forms.Label();
            this.labelPWND = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.labelModel = new System.Windows.Forms.Label();
            this.CPID = new System.Windows.Forms.Label();
            this.labelCPID = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.labelProduct = new System.Windows.Forms.Label();
            this.linkLabel1 = new System.Windows.Forms.LinkLabel();
            this.label4 = new System.Windows.Forms.Label();
            this.labelECID = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // progressBar1
            // 
            this.progressBar1.Location = new System.Drawing.Point(2, 222);
            this.progressBar1.Name = "progressBar1";
            this.progressBar1.Size = new System.Drawing.Size(347, 34);
            this.progressBar1.TabIndex = 0;
            // 
            // buttonPWND
            // 
            this.buttonPWND.Location = new System.Drawing.Point(2, 182);
            this.buttonPWND.Name = "buttonPWND";
            this.buttonPWND.Size = new System.Drawing.Size(347, 38);
            this.buttonPWND.TabIndex = 1;
            this.buttonPWND.Text = "AUTO GASTER PWN";
            this.buttonPWND.UseVisualStyleBackColor = true;
            this.buttonPWND.Click += new System.EventHandler(this.button1_Click);
            // 
            // labelmessage
            // 
            this.labelmessage.AutoSize = true;
            this.labelmessage.Location = new System.Drawing.Point(173, 232);
            this.labelmessage.Name = "labelmessage";
            this.labelmessage.Size = new System.Drawing.Size(10, 13);
            this.labelmessage.TabIndex = 2;
            this.labelmessage.Text = "-";
            // 
            // labelPWND
            // 
            this.labelPWND.AutoSize = true;
            this.labelPWND.Location = new System.Drawing.Point(115, 68);
            this.labelPWND.Name = "labelPWND";
            this.labelPWND.Size = new System.Drawing.Size(10, 13);
            this.labelPWND.TabIndex = 3;
            this.labelPWND.Text = "-";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(10, 68);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(93, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "PWND STATUS :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(52, 37);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(51, 13);
            this.label3.TabIndex = 5;
            this.label3.Text = "MODEL :";
            // 
            // labelModel
            // 
            this.labelModel.AutoSize = true;
            this.labelModel.Location = new System.Drawing.Point(115, 37);
            this.labelModel.Name = "labelModel";
            this.labelModel.Size = new System.Drawing.Size(10, 13);
            this.labelModel.TabIndex = 6;
            this.labelModel.Text = "-";
            // 
            // CPID
            // 
            this.CPID.AutoSize = true;
            this.CPID.Location = new System.Drawing.Point(65, 121);
            this.CPID.Name = "CPID";
            this.CPID.Size = new System.Drawing.Size(38, 13);
            this.CPID.TabIndex = 7;
            this.CPID.Text = "CPID :";
            // 
            // labelCPID
            // 
            this.labelCPID.AutoSize = true;
            this.labelCPID.Location = new System.Drawing.Point(115, 121);
            this.labelCPID.Name = "labelCPID";
            this.labelCPID.Size = new System.Drawing.Size(10, 13);
            this.labelCPID.TabIndex = 8;
            this.labelCPID.Text = "-";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 96);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(97, 13);
            this.label1.TabIndex = 9;
            this.label1.Text = "PRODUCT TYPE :";
            // 
            // labelProduct
            // 
            this.labelProduct.AutoSize = true;
            this.labelProduct.Location = new System.Drawing.Point(115, 96);
            this.labelProduct.Name = "labelProduct";
            this.labelProduct.Size = new System.Drawing.Size(10, 13);
            this.labelProduct.TabIndex = 10;
            this.labelProduct.Text = "-";
            // 
            // linkLabel1
            // 
            this.linkLabel1.AutoSize = true;
            this.linkLabel1.Location = new System.Drawing.Point(106, 9);
            this.linkLabel1.Name = "linkLabel1";
            this.linkLabel1.Size = new System.Drawing.Size(131, 13);
            this.linkLabel1.TabIndex = 11;
            this.linkLabel1.TabStop = true;
            this.linkLabel1.Text = "DEVICE INFORMATIONS";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(65, 149);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(38, 13);
            this.label4.TabIndex = 12;
            this.label4.Text = "ECID :";
            // 
            // labelECID
            // 
            this.labelECID.AutoSize = true;
            this.labelECID.Location = new System.Drawing.Point(115, 149);
            this.labelECID.Name = "labelECID";
            this.labelECID.Size = new System.Drawing.Size(10, 13);
            this.labelECID.TabIndex = 13;
            this.labelECID.Text = "-";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Red;
            this.button1.Location = new System.Drawing.Point(274, -1);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 14;
            this.button1.Text = "close";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(349, 259);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.labelECID);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.linkLabel1);
            this.Controls.Add(this.labelProduct);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.labelCPID);
            this.Controls.Add(this.CPID);
            this.Controls.Add(this.labelModel);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.labelPWND);
            this.Controls.Add(this.labelmessage);
            this.Controls.Add(this.buttonPWND);
            this.Controls.Add(this.progressBar1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.Text = "GASTER PWN";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ProgressBar progressBar1;
        private System.Windows.Forms.Button buttonPWND;
        private System.Windows.Forms.Label labelmessage;
        private System.Windows.Forms.Label labelPWND;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label labelModel;
        private System.Windows.Forms.Label CPID;
        private System.Windows.Forms.Label labelCPID;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label labelProduct;
        private System.Windows.Forms.LinkLabel linkLabel1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label labelECID;
        private System.Windows.Forms.Button button1;
    }
}

